import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <React.Fragment>
    {" "}
    // this tag will covered all jsx element in one element
    <h1>Vegamovies</h1>
    <center>The wolf</center>
    <p>this movie about the ......</p>
  </React.Fragment>,
  document.getElementById("root")
);
