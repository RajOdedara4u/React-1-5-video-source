import React from "react";
import ReactDOM from "react-dom";
const name = "raj";
const lname = "odedara";

const age = "20";
let min = 5;
let second = 30;
ReactDOM.render(
  <>
    <h1>
      Hello mr. {name} {lname}{" "}
    </h1>
    <p>
      your age is {10 + 9}
      your time to leave room is {min + "." + second}
    </p>
  </>,
  document.getElementById("root")
);
