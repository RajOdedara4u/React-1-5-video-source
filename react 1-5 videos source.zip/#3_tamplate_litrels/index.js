import React from "react";
import ReactDOM from "react-dom";

const name = "raj";
const age = 20;
const sname = "odedara";

let data = `hello my name is ${name}
my sirname is ${sname}
i'm ${age} yr old`; // we use the ${} sign to use js inside js

ReactDOM.render(<h1>{data}</h1>, document.getElementById("root"));
