import React from "react";
import ReactDOM from "react-dom";
// crating array of image path
const imgs = [
  "https://picsum.photos/200/300",
  "https://picsum.photos/200/340",
  "https://picsum.photos/200/370",
  "https://picsum.photos/200/380",
  "https://picsum.photos/200/360",
  "https://picsum.photos/200/343",
  "https://picsum.photos/200/310",
];
// rendaring them

ReactDOM.render(
  <>
    <center>
      <h1>Welcome to images .io</h1>
    </center>
    <a href="https://www.pexels.com/search/free%20wallpaper/">
      {" "}
      <img src={imgs[0]} />{" "}
    </a>{" "}
    //making image clickable..
    <img src={imgs[1]} />
    <img src={imgs[2]} />
    <img src={imgs[3]} />
    <img src={imgs[4]} />
    <img src={imgs[5]} />
    <img src={imgs[6]} />
    <center>
      <h1>Thanks for visit....</h1>
    </center>
  </>,
  document.getElementById("root")
);
